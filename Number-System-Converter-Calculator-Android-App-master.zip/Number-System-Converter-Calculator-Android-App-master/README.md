# Number-System-Converter-Calculator
A converter and calculator all integrated into one application.The application has three sections, one for conversions (any to any), one for calculations (any number system) and a quick chart in case you want to calculate it yourself or learn it yourself.

## Available on Google Play Store
https://play.google.com/store/apps/details?id=com.tekstorm.nusconumbersystemconverter&hl=en
